#hyperparameters and seed
import tensorflow as tf
NUM_POINTS =4096
NUM_CLASSES = 3
BATCH_SIZE = 32
tf.random.set_seed(1234)